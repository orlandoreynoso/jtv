
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="pie">
						<div class="group">
						<p>Canal Jesustv |  Ciudad de Guatemala</p>		
						<p>6av. 39-35 zona 8 | Teléfonos: (502) 2440-4032 / 2440-4719</p>
						<p>Desarrollado por: <a href="http://www.orlandoreynoso.com">@orlandoreynoso</a></p>
						</div>
					</div>										
				</div>
			</div>
		</div>		
	</footer>
	<script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/js/bootstrap.min.js'></script>
	<script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/js/jquery-3.1.1.min.js'></script>
	<script src="<?php bloginfo('stylesheet_directory'); ?>/js/prefixfree.min.js"></script>	
	<?php wp_footer(); ?>
</body>
</html>