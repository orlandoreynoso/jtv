<article class="c-info">
	<div  class="col-xs-12 col-sm-6 col-md-3">
		<div class="div1">
			<a class="li1" href="https://livestream.com/canaljesustv/events/4834657">
				<span><i class="si fa fa-tv"></i>Tv en linea</span>					
			</a>
		</div>
	</div>
	<div class="col-xs-12 col-sm-6 col-md-3">
		<div class="div2">
			<a class="li2" href="http://www.canaljesustv.com/padre-hugo-estrada/">
				<span><i class="si fa fa-caret-right"></i>Padre Hugo Estrada</span>
			</a>
		</div>	
	</div>
	<div class="col-xs-12 col-sm-6 col-md-3">
		<div class="div3">
			<a class="li3" href="https://play.google.com/store/apps/details?id=com.JesusTv&hl=es">
				<span><i class="si fa fa-angle-double-down"></i>Descarga nuestra APP</span>
			</a>
		</div> 
	</div>
	<div class="col-xs-12 col-sm-6 col-md-3">
		<div class="div4">
			<a class="li4" href="http://www.canaljesustv.com/category/santos-del-mes/">
				<span><i class="si fa fa-book"></i>Santo del día</span>
			</a>
		</div> 
	</div>
</article>